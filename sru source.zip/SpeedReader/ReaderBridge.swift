import SwiftUI
import UIKit
import WebKit

/// Connects the reader page to iPadOS: hands it books opened from other apps,
/// keeps the screen awake while reading, and opens web links in Safari.
@MainActor
final class ReaderBridge: NSObject, ObservableObject, WKScriptMessageHandler, WKNavigationDelegate {
    weak var webView: WKWebView?
    private var pageLoaded = false
    private var pending: [(name: String, data: Data)] = []

    // MARK: Books opened from Files, Books, Mail and other apps

    func open(_ url: URL) {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }

        var data: Data?
        var coordError: NSError?
        // Coordinated read so files still in iCloud are downloaded first
        NSFileCoordinator().coordinate(readingItemAt: url, options: [], error: &coordError) { readURL in
            data = try? Data(contentsOf: readURL)
        }
        guard let bytes = data else {
            showError("Couldn’t open \(url.lastPathComponent).")
            return
        }
        pending.append((url.lastPathComponent, bytes))
        flush()
    }

    private func flush() {
        guard pageLoaded, let webView else { return }
        let items = pending
        pending.removeAll()
        for item in items {
            let js = "window.ssruIncoming && window.ssruIncoming(\(jsString(item.name)), '\(item.data.base64EncodedString())')"
            webView.evaluateJavaScript(js, completionHandler: nil)
        }
    }

    private func showError(_ message: String) {
        webView?.evaluateJavaScript("window.ssruError && window.ssruError(\(jsString(message)))", completionHandler: nil)
    }

    private func jsString(_ s: String) -> String {
        guard let d = try? JSONSerialization.data(withJSONObject: [s]),
              var str = String(data: d, encoding: .utf8) else { return "''" }
        str.removeFirst(); str.removeLast()   // strip the [ ] around the one-item array
        return str
    }

    // MARK: Messages from the page

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let body = message.body as? [String: Any], let type = body["type"] as? String else { return }
        switch type {
        case "wake":
            UIApplication.shared.isIdleTimerDisabled = (body["on"] as? Bool) ?? false
        default:
            break
        }
    }

    // MARK: Navigation

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        pageLoaded = true
        flush()
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction) async -> WKNavigationActionPolicy {
        if let url = navigationAction.request.url, let scheme = url.scheme, scheme == "http" || scheme == "https" {
            _ = await UIApplication.shared.open(url)
            return .cancel
        }
        return .allow
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        pageLoaded = false
        webView.reload()
    }
}
